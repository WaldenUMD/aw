BEGIN;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL DEFAULT '',
    last_name  TEXT NOT NULL DEFAULT '',
    email      TEXT,
    phone      TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS cars (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    make  TEXT,
    model TEXT,
    plate TEXT,
    vin   TEXT,
    year  INTEGER,
    color TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    car_id    INTEGER NOT NULL REFERENCES cars(id),
    fault_desc TEXT,
    appointment_at TEXT,
    pickup_due_at TEXT,
    work_scope TEXT,
    status     TEXT NOT NULL DEFAULT 'Nowe',
    priority   TEXT NOT NULL DEFAULT 'Normalny',
    labor_net      REAL NOT NULL DEFAULT 0,
    labor_vat_rate REAL NOT NULL DEFAULT 23,
    parts_pickup_at TEXT,
    done_at         TEXT,
    is_deleted     INTEGER NOT NULL DEFAULT 0,
    deleted_at     TEXT,
    deleted_reason TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    name     TEXT NOT NULL,
    qty      REAL NOT NULL DEFAULT 1,
    unit_net REAL NOT NULL DEFAULT 0,
    vat_rate REAL NOT NULL DEFAULT 23,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS order_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL DEFAULT 'Warsztat',
    kind TEXT NOT NULL DEFAULT 'Informacja',
    body TEXT NOT NULL DEFAULT '',
    parts_pickup_at TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS order_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL DEFAULT 'System',
    event_type TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    comment TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS service_catalog (
    code TEXT PRIMARY KEY,
    name_pl TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS order_services (
    order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
    service_code TEXT REFERENCES service_catalog(code),
    PRIMARY KEY(order_id, service_code)
);

INSERT OR IGNORE INTO service_catalog(code, name_pl, sort_order) VALUES
('DIAG','Diagnostyka',10),
('INSPECT','Przegląd okresowy',20),
('OIL','Wymiana oleju',30),
('FILTERS','Wymiana filtrów',40),
('TIRES','Opony',50),
('BRAKES','Hamulce',60),
('SUSP','Zawieszenie',70),
('AC','Klimatyzacja',80),
('ELEC','Elektryka',90),
('ENGINE','Silnik',100),
('TIMING','Rozrząd',110),
('EXHAUST','Układ wydechowy',120),
('GEOM','Geometria kół',130),
('BATTERY','Akumulator',140),
('VULC','Wulkanizacja',150);

CREATE TABLE IF NOT EXISTS ui_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

INSERT OR IGNORE INTO ui_settings(key,value) VALUES
('app.version','AutoWorks 1.0.1');

CREATE TABLE IF NOT EXISTS parts_inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    manufacturer TEXT,
    part_no TEXT,
    qty_on_hand REAL NOT NULL DEFAULT 0,
    purchase_net REAL NOT NULL DEFAULT 0,
    purchase_vat REAL NOT NULL DEFAULT 0,
    sale_net REAL NOT NULL DEFAULT 0,
    sale_vat REAL NOT NULL DEFAULT 0,
    location TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS inventory_moves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    part_id INTEGER NOT NULL REFERENCES parts_inventory(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL DEFAULT 'System',
    kind TEXT NOT NULL,
    qty_delta REAL NOT NULL,
    note TEXT,
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

-- Compatibility views (older UI expected parts_movements / parts_movments)
DROP VIEW IF EXISTS parts_movements;
CREATE VIEW parts_movements AS
SELECT id, part_id, user_name, kind, qty_delta, note, created_at
FROM inventory_moves;

DROP VIEW IF EXISTS parts_movments;
CREATE VIEW parts_movments AS
SELECT id, part_id, user_name, kind, qty_delta, note, created_at
FROM inventory_moves;

COMMIT;


CREATE TABLE IF NOT EXISTS diagnostic_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER REFERENCES orders(id) ON DELETE SET NULL,
    employee_code TEXT NOT NULL DEFAULT '',
    vin TEXT,
    plate TEXT,
    original_file_name TEXT NOT NULL,
    stored_file_name TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    source_folder TEXT,
    file_ext TEXT,
    file_size INTEGER NOT NULL DEFAULT 0,
    uploaded_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_order_id ON diagnostic_files(order_id);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_uploaded_at ON diagnostic_files(uploaded_at DESC);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_vin ON diagnostic_files(vin);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_plate ON diagnostic_files(plate);

