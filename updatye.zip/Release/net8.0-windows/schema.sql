BEGIN;

CREATE TABLE IF NOT EXISTS clients (
    id BIGSERIAL PRIMARY KEY,
    first_name TEXT NOT NULL DEFAULT '',
    last_name  TEXT NOT NULL DEFAULT '',
    email      TEXT,
    phone      TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cars (
    id BIGSERIAL PRIMARY KEY,
    client_id BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    make  TEXT,
    model TEXT,
    plate TEXT,
    vin   TEXT,
    year  INT,
    color TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
    id BIGSERIAL PRIMARY KEY,
    client_id BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    car_id    BIGINT NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
    fault_desc TEXT,
    appointment_at TIMESTAMP,
    pickup_due_at TIMESTAMP,
    work_scope TEXT,
    status     TEXT NOT NULL DEFAULT 'Nowe',
    priority   TEXT NOT NULL DEFAULT 'Normalny',
    labor_net       NUMERIC(12,2) NOT NULL DEFAULT 0,
    labor_vat_rate  NUMERIC(5,2)  NOT NULL DEFAULT 23,
    parts_pickup_at DATE,
    done_at         TIMESTAMPTZ,
    is_deleted     BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at     TIMESTAMPTZ,
    deleted_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    name     TEXT NOT NULL,
    qty      NUMERIC(12,3) NOT NULL DEFAULT 1,
    unit_net NUMERIC(12,2) NOT NULL DEFAULT 0,
    vat_rate NUMERIC(5,2)  NOT NULL DEFAULT 23,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_comments (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL DEFAULT 'Warsztat',
    kind TEXT NOT NULL DEFAULT 'Informacja',
    body TEXT NOT NULL DEFAULT '',
    parts_pickup_at DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_events (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT REFERENCES orders(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL DEFAULT 'System',
    event_type TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS service_catalog (
    code TEXT PRIMARY KEY,
    name_pl TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order INT NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS order_services (
    order_id BIGINT REFERENCES orders(id) ON DELETE CASCADE,
    service_code TEXT REFERENCES service_catalog(code),
    PRIMARY KEY(order_id, service_code)
);

INSERT INTO service_catalog(code, name_pl, sort_order) VALUES
('DIAG','Diagnostyka',10),
('INSPECT','Przegląd okresowy',20),
('OIL','Wymiana oleju',30),
('FILTERS','Wymiana filtrów',40),
('TIRES','Opony',50),
('BRAKES','Hamulce',60),
('SUSP','Zawieszenie',70),
('AC','Klimatyzacja',80),
('ELEC','Elektryka',90),
('ENGINE','Silnik',100),
('TIMING','Rozrząd',110),
('EXHAUST','Układ wydechowy',120),
('GEOM','Geometria kół',130),
('BATTERY','Akumulator',140),
('VULC','Wulkanizacja',150)
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS ui_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO ui_settings(key,value) VALUES
('app.version','AutoWorks 1.0.1')
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS parts_inventory (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    manufacturer TEXT,
    part_no TEXT,
    qty_on_hand NUMERIC(12,3) NOT NULL DEFAULT 0,
    purchase_net NUMERIC(12,2) NOT NULL DEFAULT 0,
    purchase_vat NUMERIC(12,2) NOT NULL DEFAULT 0,
    sale_net NUMERIC(12,2) NOT NULL DEFAULT 0,
    sale_vat NUMERIC(12,2) NOT NULL DEFAULT 0,
    location TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS inventory_moves (
    id BIGSERIAL PRIMARY KEY,
    part_id BIGINT NOT NULL REFERENCES parts_inventory(id) ON DELETE CASCADE,
    user_name TEXT NOT NULL DEFAULT 'System',
    kind TEXT NOT NULL,
    qty_delta NUMERIC(12,3) NOT NULL,
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Compatibility views (older UI expected parts_movements / parts_movments)
CREATE OR REPLACE VIEW parts_movements AS
SELECT id, part_id, user_name, kind, qty_delta, note, created_at
FROM inventory_moves;

CREATE OR REPLACE VIEW parts_movments AS
SELECT id, part_id, user_name, kind, qty_delta, note, created_at
FROM inventory_moves;

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_deleted ON orders(is_deleted);

COMMIT;


-- Labor / Robocizna cennik
CREATE TABLE IF NOT EXISTS labor_catalog (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    price NUMERIC(10,2) NOT NULL DEFAULT 0,
    price_from NUMERIC(10,2) NOT NULL DEFAULT 0,
    price_to NUMERIC(10,2) NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order INT NOT NULL DEFAULT 0
);

ALTER TABLE labor_catalog ADD COLUMN IF NOT EXISTS price_from NUMERIC(10,2) NOT NULL DEFAULT 0;
ALTER TABLE labor_catalog ADD COLUMN IF NOT EXISTS price_to NUMERIC(10,2) NOT NULL DEFAULT 0;
UPDATE labor_catalog SET price_from = COALESCE(NULLIF(price_from, 0), price, 0) WHERE COALESCE(price_from, 0) = 0;
UPDATE labor_catalog SET price_to   = COALESCE(NULLIF(price_to, 0),   price, 0) WHERE COALESCE(price_to, 0) = 0;

CREATE INDEX IF NOT EXISTS ix_labor_catalog_name ON labor_catalog (name);

-- upgrade: termin wizyty klienta
ALTER TABLE orders ADD COLUMN IF NOT EXISTS appointment_at TIMESTAMP;

ALTER TABLE orders ADD COLUMN IF NOT EXISTS pickup_due_at TIMESTAMP;

ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS work_scope TEXT;


CREATE TABLE IF NOT EXISTS diagnostic_files (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT REFERENCES orders(id) ON DELETE SET NULL,
    employee_code TEXT NOT NULL DEFAULT '',
    vin TEXT,
    plate TEXT,
    original_file_name TEXT NOT NULL,
    stored_file_name TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    source_folder TEXT,
    file_ext TEXT,
    file_size BIGINT NOT NULL DEFAULT 0,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_diagnostic_files_order_id ON diagnostic_files(order_id);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_uploaded_at ON diagnostic_files(uploaded_at DESC);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_vin ON diagnostic_files(vin);
CREATE INDEX IF NOT EXISTS idx_diagnostic_files_plate ON diagnostic_files(plate);
